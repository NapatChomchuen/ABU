# basketball > 2022-11-27 2:23pm
https://universe.roboflow.com/034-ganesh-kumar-m-v-cs-r2lwe/basketball-lhqoe

Provided by a Roboflow user
License: CC BY 4.0

